// app/printers/page.js (Server Component)
import { SITE } from '@/lib/site';
import PrintersClient from './_printersClient';
import { getCollectionData } from '@/lib/serverData';


// تصدير metadata للصفحة
export const metadata = {
  title: 'الطابعات',
  description: 'اكتشف مجموعة متنوعة من الطابعات: طابعات ليزر، نافثة للحبر، وحرارية — أسعار، مواصفات، ونصائح لاختيار الطابعة المثالية للمكتب أو المنزل.',
  keywords: [
    'طابعات', 'طابعة ليزر', 'طابعة نافثة للحبر', 'طابعة حرارية', 'طابعات مكتبية', 'طابعات تجارية', 'طابعة صور', 'طابعة ملصقات', 'أجهزة طباعة', 'ورق طباعة', 'حبر طابعات', 'ماسح ضوئي', 'طابعة متعددة الوظائف', 'طابعة إيصالات'
  ],
  openGraph: {
    url: `${SITE.url}/printers`,
    title: 'الطابعات',
    description: 'تصفح أحدث أنواع الطابعات: مواصفات تفصيلية وأسعار تنافسية لمساعدتك في اختيار الأنسب.',
    type: 'website'
  }
};




async function fetchPrintersData() {
  try {
    // قراءة مباشرة من قاعدة البيانات بدل fetch لنفس الـ API route
    const result = await getCollectionData('printers');

    if (!result.success) {
      throw new Error(result.error || 'فشل في جلب البيانات');
    }

    const apiData = result.data;

    // البحث عن بيانات الطابعات
    let printerData = null;

    if (Array.isArray(apiData) && apiData.length > 0) {
      printerData = apiData[0];
    } else if (apiData && typeof apiData === 'object') {
      printerData = apiData;
    } else {
      throw new Error('لم يتم العثور على بيانات الطابعات في الاستجابة');
    }

    // معالجة البيانات مع قيم افتراضية شاملة
    const processedData = {
      _id: printerData._id || 'printers-page',
      pageTitle: printerData.pageTitle || 'الطابعات المتقدمة',
      pageSubtitle: printerData.pageSubtitle || 'اكتشف أفضل الطابعات المكتبية والتجارية لجميع احتياجاتك مع ضمان الجودة والأداء العالي',
      categories: printerData.categories || [
        {
          id: 'all',
          name: 'جميع المنتجات',
          icon: 'printer',
          color: 'from-purple-600 to-blue-600',
        },
        {
          id: 'laser',
          name: 'طابعات ليزر',
          icon: 'zap',
          color: 'from-blue-600 to-cyan-600',
        },
        {
          id: 'inkjet',
          name: 'طابعات حبر',
          icon: 'printer',
          color: 'from-green-600 to-teal-600',
        },
        {
          id: 'thermal',
          name: 'طابعات حرارية',
          icon: 'monitor',
          color: 'from-orange-600 to-red-600',
        },
      ],
      filters: printerData.filters || {
        sortOptions: [
          { value: 'name', label: 'الاسم (أ-ي)' },
          { value: 'price-low', label: 'السعر: من الأقل للأعلى' },
          { value: 'price-high', label: 'السعر: من الأعلى للأقل' },
          { value: 'rating', label: 'الأعلى تقييماً' },
          { value: 'performance', label: 'الأفضل أداءً' },
        ],
      },
      products: printerData.products || [],
    };

    return processedData;

  } catch (error) {
    console.error('خطأ في جلب بيانات الطابعات:', error);
    
    // إرجاع بيانات افتراضية في حالة الخطأ
    return {
      _id: 'printers-fallback',
      pageTitle: 'الطابعات المتقدمة',
      pageSubtitle: 'اكتشف أفضل الطابعات المكتبية والتجارية لجميع احتياجاتك',
      categories: [
        {
          id: 'all',
          name: 'جميع المنتجات',
          icon: 'printer',
          color: 'from-purple-600 to-blue-600',
        },
      ],
      filters: {
        sortOptions: [
          { value: 'name', label: 'الاسم' },
          { value: 'price-low', label: 'السعر: من الأقل للأعلى' },
          { value: 'price-high', label: 'السعر: من الأعلى للأقل' },
          { value: 'rating', label: 'التقييم' },
        ],
      },
      products: [],
      error: error.message,
    };
  }
}

export default async function PrintersPage() {
  const data = await fetchPrintersData();

  return <PrintersClient initialData={data} />;
}